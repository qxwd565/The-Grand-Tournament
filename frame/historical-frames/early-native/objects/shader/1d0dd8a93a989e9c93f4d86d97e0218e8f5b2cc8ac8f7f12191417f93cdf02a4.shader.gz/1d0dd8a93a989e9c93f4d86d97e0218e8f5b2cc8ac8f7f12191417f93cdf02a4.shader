Shader "Hero/AddMultiplyFXScrolling" {
Properties {
 _Color ("Tint Color", Color) = (0.5,0.5,0.5,0.5)
 _MainTex ("Main Texture", 2D) = "black" { }
 _Intensity ("Intensity", Float) = 1
 _FxTex ("FX Texture", 2D) = "black" { }
 _FxIntensity ("FX Intensity", Float) = 1
 _ScrollX ("FX Scroll X", Float) = 0
 _ScrollY ("FX Scroll Y", Float) = 0
 _ScaleX ("FX Scale X", Float) = 1
 _ScaleY ("FX Scale Y", Float) = 1
 _GlowColor ("Glow Color", Color) = (1,1,1,1)
 _GlowIntensity ("Glow Intensity", Float) = 0
 _GlowAddMul ("Glow Add/Multiply", Range(0,1)) = 0
 _LightingBlend ("Ambient Lighting Blend", Float) = 0
}
SubShader { 
 Tags { "QUEUE"="Transparent" "IGNOREPROJECTOR"="true" "RenderType"="GlowTransparent" }
 Pass {
  Tags { "QUEUE"="Transparent" "IGNOREPROJECTOR"="true" "RenderType"="GlowTransparent" }
  BindChannels {
   Bind "vertex", Vertex
   Bind "color", Color
   Bind "texcoord", TexCoord
  }
  ZWrite Off
  Cull Off
  Fog {
   Color (0,0,0,0)
  }
  Blend One OneMinusSrcAlpha
  GpuProgramID 5953
Program "vp" {
SubProgram "gles " {
"!!GLES
#version 100

#ifdef VERTEX
attribute vec4 _glesVertex;
attribute vec4 _glesColor;
attribute vec4 _glesMultiTexCoord0;
uniform highp vec4 _Time;
uniform highp mat4 glstate_matrix_mvp;
uniform lowp vec4 glstate_lightmodel_ambient;
uniform lowp vec4 _LightColor0;
uniform lowp vec4 _Color;
uniform mediump float _ScrollX;
uniform mediump float _ScrollY;
uniform mediump float _ScaleX;
uniform mediump float _ScaleY;
uniform mediump float _LightingBlend;
uniform highp vec4 _MainTex_ST;
varying highp vec2 xlv_TEXCOORD0;
varying highp vec2 xlv_TEXCOORD1;
varying lowp vec4 xlv_COLOR;
void main ()
{
  lowp vec4 tmpvar_1;
  highp vec2 tmpvar_2;
  tmpvar_2 = ((_glesMultiTexCoord0.xy * _MainTex_ST.xy) + _MainTex_ST.zw);
  highp vec2 tmpvar_3;
  tmpvar_3.x = ((tmpvar_2.x * _ScaleX) + (_Time.x * _ScrollX));
  tmpvar_3.y = ((tmpvar_2.y * _ScaleY) + (_Time.x * _ScrollY));
  mediump vec4 tmpvar_4;
  lowp vec4 y_5;
  y_5 = (((glstate_lightmodel_ambient * 2.0) + _LightColor0) * _glesColor);
  tmpvar_4 = mix (_glesColor, y_5, vec4(_LightingBlend));
  tmpvar_1 = (tmpvar_4 * _Color.w);
  gl_Position = (glstate_matrix_mvp * _glesVertex);
  xlv_TEXCOORD0 = tmpvar_2;
  xlv_TEXCOORD1 = tmpvar_3;
  xlv_COLOR = tmpvar_1;
}


#endif
#ifdef FRAGMENT
uniform sampler2D _MainTex;
uniform lowp vec4 _Color;
uniform highp float _Intensity;
uniform sampler2D _FxTex;
uniform highp float _FxIntensity;
varying highp vec2 xlv_TEXCOORD0;
varying highp vec2 xlv_TEXCOORD1;
varying lowp vec4 xlv_COLOR;
void main ()
{
  mediump vec4 col_1;
  mediump vec4 fx_2;
  mediump vec4 tex_3;
  lowp vec4 tmpvar_4;
  tmpvar_4 = texture2D (_MainTex, xlv_TEXCOORD0);
  tex_3 = tmpvar_4;
  lowp vec4 tmpvar_5;
  tmpvar_5 = texture2D (_FxTex, xlv_TEXCOORD1);
  highp vec4 tmpvar_6;
  tmpvar_6 = (tmpvar_5 * _FxIntensity);
  fx_2 = tmpvar_6;
  col_1.xyz = (_Color * tex_3).xyz;
  col_1.w = (tex_3.w * (_Color.w - tex_3.w));
  lowp vec4 tmpvar_7;
  highp vec4 tmpvar_8;
  tmpvar_8 = clamp (((2.0 * col_1) * (
    (fx_2 * _Intensity)
   * xlv_COLOR)), 0.0, 1.0);
  tmpvar_7 = tmpvar_8;
  gl_FragData[0] = tmpvar_7;
}


#endif
"
}
}
Program "fp" {
SubProgram "gles " {
"!!GLES"
}
}
 }
}
Fallback Off
}
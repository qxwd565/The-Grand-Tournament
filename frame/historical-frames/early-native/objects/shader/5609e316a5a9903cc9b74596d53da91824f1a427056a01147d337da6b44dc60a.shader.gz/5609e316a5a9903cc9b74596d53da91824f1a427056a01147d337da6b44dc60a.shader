Shader "Custom/Card/UnlitTextureReflection" {
Properties {
 _MainTex ("Base (RGB)", 2D) = "white" { }
 _SpecTex ("Specular (RGB)", 2D) = "white" { }
 _ReflTex ("Reflection (RGB)", 2D) = "white" { }
 _ReflectionIntensity ("Reflection Intensity", Float) = 1
 _ReflectionFalloff ("Reflection Falloff", Float) = 2.5
 _ReflectionRotation ("Reflection Rotation", Float) = 1
 _LightingBlend ("Ambient Lighting Blend", Float) = 0
 _Seed ("Seed", Float) = 0
}
SubShader { 
 Tags { "LIGHTMODE"="Always" "RenderType"="Opaque" "Highlight"="true" }
 Pass {
  Tags { "LIGHTMODE"="Always" "RenderType"="Opaque" "Highlight"="true" }
  BindChannels {
   Bind "color", Color
   Bind "normal", Normal
   Bind "texcoord", TexCoord
  }
  Cull Off
  Fog {
   Color (0,0,0,1)
  }
  GpuProgramID 5364
Program "vp" {
SubProgram "gles " {
"!!GLES
#version 100

#ifdef VERTEX
attribute vec4 _glesVertex;
attribute vec3 _glesNormal;
attribute vec4 _glesMultiTexCoord0;
uniform highp mat4 glstate_matrix_mvp;
uniform highp mat4 _Object2World;
uniform lowp vec4 glstate_lightmodel_ambient;
uniform lowp vec4 _LightColor0;
uniform mediump float _ReflectionRotation;
uniform mediump float _LightingBlend;
uniform highp float _ShaderTime;
uniform highp vec4 _MainTex_ST;
varying lowp vec4 xlv_COLOR1;
varying highp vec2 xlv_TEXCOORD0;
varying highp vec2 xlv_TEXCOORD1;
void main ()
{
  mediump vec3 ws_1;
  lowp vec4 tmpvar_2;
  highp vec2 tmpvar_3;
  highp vec2 tmpvar_4;
  tmpvar_3 = ((_glesMultiTexCoord0.xy * _MainTex_ST.xy) + _MainTex_ST.zw);
  highp mat3 tmpvar_5;
  tmpvar_5[0] = _Object2World[0].xyz;
  tmpvar_5[1] = _Object2World[1].xyz;
  tmpvar_5[2] = _Object2World[2].xyz;
  highp vec3 tmpvar_6;
  tmpvar_6 = (_Object2World * _glesVertex).xyz;
  ws_1 = tmpvar_6;
  tmpvar_4 = (((
    -(tmpvar_3.x)
   * 
    ((tmpvar_5 * _glesNormal) * 0.3)
  ) + ws_1) * 0.07).xz;
  tmpvar_4 = (tmpvar_4 + (_ShaderTime * _ReflectionRotation));
  mediump vec4 tmpvar_7;
  lowp vec4 y_8;
  y_8 = ((glstate_lightmodel_ambient * 2.0) + _LightColor0);
  tmpvar_7 = mix (vec4(1.0, 1.0, 1.0, 1.0), y_8, vec4(_LightingBlend));
  tmpvar_2 = tmpvar_7;
  gl_Position = (glstate_matrix_mvp * _glesVertex);
  xlv_COLOR1 = tmpvar_2;
  xlv_TEXCOORD0 = tmpvar_3;
  xlv_TEXCOORD1 = tmpvar_4;
}


#endif
#ifdef FRAGMENT
uniform sampler2D _MainTex;
uniform sampler2D _SpecTex;
uniform sampler2D _ReflTex;
uniform mediump float _ReflectionIntensity;
varying lowp vec4 xlv_COLOR1;
varying highp vec2 xlv_TEXCOORD0;
varying highp vec2 xlv_TEXCOORD1;
void main ()
{
  mediump vec4 mask_1;
  mediump vec4 col_2;
  lowp vec4 tmpvar_3;
  tmpvar_3 = texture2D (_MainTex, xlv_TEXCOORD0);
  col_2 = tmpvar_3;
  lowp vec4 tmpvar_4;
  tmpvar_4 = texture2D (_SpecTex, xlv_TEXCOORD0);
  mask_1 = tmpvar_4;
  lowp vec4 tmpvar_5;
  highp vec2 P_6;
  P_6 = (xlv_TEXCOORD1 * 2.0);
  tmpvar_5 = texture2D (_ReflTex, P_6);
  lowp vec4 tmpvar_7;
  mediump vec4 tmpvar_8;
  tmpvar_8 = clamp (((col_2 + 
    ((tmpvar_5 * mask_1) * (_ReflectionIntensity * 0.5))
  ) * xlv_COLOR1), 0.0, 1.0);
  tmpvar_7 = tmpvar_8;
  gl_FragData[0] = tmpvar_7;
}


#endif
"
}
}
Program "fp" {
SubProgram "gles " {
"!!GLES"
}
}
 }
}
Fallback "Diffuse"
}
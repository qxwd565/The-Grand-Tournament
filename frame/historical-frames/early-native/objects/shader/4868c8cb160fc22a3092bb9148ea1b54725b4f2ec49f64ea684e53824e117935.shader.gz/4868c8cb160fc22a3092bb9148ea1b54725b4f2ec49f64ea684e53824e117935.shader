Shader "Custom/FX_GhostCard" {
Properties {
 _Color ("Tint Color", Color) = (0.5,0.5,0.5,0.5)
 _MainTex ("Main Texture", 2D) = "black" { }
 _TexIntensity ("Main Texture Intensity", Float) = 1
 _Intensity ("Intensity", Float) = 1
 _FxTex ("FX Texture", 2D) = "black" { }
 _FxIntensity ("FX Intensity", Float) = 1
 _FxDistortion ("FX Distortion", Float) = 1
 _ScrollX ("FX Scroll X", Float) = 0
 _ScrollY ("FX Scroll Y", Float) = 0
 _ScaleX ("FX Scale X", Float) = 1
 _ScaleY ("FX Scale Y", Float) = 1
 _Seed ("Seed", Float) = 0
}
SubShader { 
 Tags { "QUEUE"="Transparent" "IGNOREPROJECTOR"="true" "RenderType"="Transparent" }
 Pass {
  Tags { "QUEUE"="Transparent" "IGNOREPROJECTOR"="true" "RenderType"="Transparent" }
  BindChannels {
   Bind "vertex", Vertex
   Bind "color", Color
   Bind "texcoord", TexCoord
  }
  ZWrite Off
  Cull Off
  Fog {
   Color (0,0,0,1)
  }
  Blend One OneMinusSrcAlpha
  GpuProgramID 28202
Program "vp" {
SubProgram "gles " {
"!!GLES
#version 100

#ifdef VERTEX
attribute vec4 _glesVertex;
attribute vec4 _glesColor;
attribute vec4 _glesMultiTexCoord0;
uniform highp vec4 _Time;
uniform highp mat4 glstate_matrix_mvp;
uniform mediump float _ScrollX;
uniform mediump float _ScrollY;
uniform mediump float _ScaleX;
uniform mediump float _ScaleY;
uniform mediump float _Seed;
uniform highp vec4 _MainTex_ST;
varying highp vec2 xlv_TEXCOORD0;
varying highp vec2 xlv_TEXCOORD1;
varying lowp vec4 xlv_COLOR;
void main ()
{
  highp vec2 tmpvar_1;
  tmpvar_1 = ((_glesMultiTexCoord0.xy * _MainTex_ST.xy) + _MainTex_ST.zw);
  highp float tmpvar_2;
  tmpvar_2 = (_Time.x + _Seed);
  highp vec2 tmpvar_3;
  tmpvar_3.x = ((tmpvar_1.x * _ScaleX) + (tmpvar_2 * _ScrollX));
  tmpvar_3.y = ((tmpvar_1.y * _ScaleY) + (tmpvar_2 * _ScrollY));
  gl_Position = (glstate_matrix_mvp * _glesVertex);
  xlv_TEXCOORD0 = tmpvar_1;
  xlv_TEXCOORD1 = tmpvar_3;
  xlv_COLOR = _glesColor;
}


#endif
#ifdef FRAGMENT
uniform sampler2D _MainTex;
uniform mediump float _TexIntensity;
uniform lowp vec4 _Color;
uniform highp float _Intensity;
uniform sampler2D _FxTex;
uniform mediump float _FxIntensity;
uniform mediump float _FxDistortion;
varying highp vec2 xlv_TEXCOORD0;
varying highp vec2 xlv_TEXCOORD1;
varying lowp vec4 xlv_COLOR;
void main ()
{
  mediump vec4 col_1;
  lowp vec4 tmpvar_2;
  tmpvar_2 = texture2D (_FxTex, xlv_TEXCOORD1);
  mediump float tmpvar_3;
  tmpvar_3 = (tmpvar_2 * _FxIntensity).x;
  highp vec2 tmpvar_4;
  tmpvar_4.x = (xlv_TEXCOORD0.x + ((tmpvar_3 * 0.01) * _FxDistortion));
  tmpvar_4.y = (xlv_TEXCOORD0.y + ((tmpvar_3 * 0.005) * _FxDistortion));
  lowp vec4 tmpvar_5;
  tmpvar_5 = texture2D (_MainTex, tmpvar_4);
  mediump vec4 tmpvar_6;
  tmpvar_6 = (tmpvar_5 * _TexIntensity);
  col_1.xyz = ((_Color.xyz * vec3(tmpvar_3)) * 2.0);
  col_1.w = tmpvar_3;
  col_1 = (((
    ((2.0 * col_1) * ((vec4(tmpvar_3) * _Intensity) * xlv_COLOR))
   + tmpvar_6) * tmpvar_6.w) * _Color.w);
  mediump float tmpvar_7;
  tmpvar_7 = dot (vec3(0.3, 0.59, 0.11), col_1.xyz);
  mediump vec4 tmpvar_8;
  tmpvar_8.x = tmpvar_7;
  tmpvar_8.y = tmpvar_7;
  tmpvar_8.z = tmpvar_7;
  tmpvar_8.w = col_1.w;
  col_1 = (mix (col_1, tmpvar_8, vec4(0.7, 0.7, 0.7, 0.7)) * vec4(1.2, 1.2, 1.7, 1.4));
  lowp vec4 tmpvar_9;
  mediump vec4 tmpvar_10;
  tmpvar_10 = clamp (col_1, 0.0, 1.0);
  tmpvar_9 = tmpvar_10;
  gl_FragData[0] = tmpvar_9;
}


#endif
"
}
}
Program "fp" {
SubProgram "gles " {
"!!GLES"
}
}
 }
}
Fallback Off
}
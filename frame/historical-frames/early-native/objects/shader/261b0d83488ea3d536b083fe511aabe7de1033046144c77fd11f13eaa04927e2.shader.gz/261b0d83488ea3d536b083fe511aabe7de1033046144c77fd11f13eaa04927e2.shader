Shader "Custom/Selection/Highlight" {
Properties {
 _Color ("Base Color", Color) = (0.5,0.5,0.5,1)
 _HiColor ("Hot Color", Color) = (0.5,0.5,0.5,1)
 _Colorize ("Colorize", Color) = (1,1,1,1)
 _ColorIntensity ("Color Intensity", Float) = 1
 _Intensity ("Intensity", Float) = 1
 _FlareTex ("Flare Texture", 2D) = "white" { }
 _FlareIntensity ("Flare Intensity", Float) = 1
 _VflareSpeed ("Flare V Speed", Float) = 1
 _UflareScale ("Flare U Scale", Float) = 1
 _VflareScale ("Flare V Scale", Float) = 1
 _MainTex ("Main Texture", 2D) = "black" { }
 _Seed ("_Seed", Float) = 0
}
SubShader { 
 Tags { "QUEUE"="Transparent" "IGNOREPROJECTOR"="true" "RenderType"="Transparent" }
 Pass {
  Tags { "QUEUE"="Transparent" "IGNOREPROJECTOR"="true" "RenderType"="Transparent" }
  ZWrite Off
  Cull Off
  Fog {
   Color (0,0,0,1)
  }
  Blend SrcAlpha OneMinusSrcAlpha
  ColorMask RGB
  GpuProgramID 53583
Program "vp" {
SubProgram "gles " {
"!!GLES
#version 100

#ifdef VERTEX
attribute vec4 _glesVertex;
attribute vec4 _glesColor;
attribute vec4 _glesMultiTexCoord0;
attribute vec4 _glesMultiTexCoord1;
uniform highp mat4 glstate_matrix_mvp;
uniform highp vec4 _MainTex_ST;
varying mediump vec2 xlv_TEXCOORD0;
varying mediump vec2 xlv_TEXCOORD1;
varying lowp vec4 xlv_COLOR;
void main ()
{
  mediump vec2 tmpvar_1;
  mediump vec2 tmpvar_2;
  tmpvar_1 = ((_glesMultiTexCoord0.xy * _MainTex_ST.xy) + _MainTex_ST.zw);
  tmpvar_2 = ((_glesMultiTexCoord1.xy * _MainTex_ST.xy) + _MainTex_ST.zw);
  gl_Position = (glstate_matrix_mvp * _glesVertex);
  xlv_TEXCOORD0 = tmpvar_1;
  xlv_TEXCOORD1 = tmpvar_2;
  xlv_COLOR = _glesColor;
}


#endif
#ifdef FRAGMENT
uniform sampler2D _MainTex;
uniform sampler2D _FlareTex;
uniform lowp vec4 _Color;
uniform lowp vec4 _Colorize;
uniform lowp vec4 _HiColor;
uniform mediump float _ColorIntensity;
uniform mediump float _Intensity;
uniform mediump float _FlareIntensity;
uniform mediump float _VflareSpeed;
uniform mediump float _UflareScale;
uniform mediump float _VflareScale;
uniform highp float _ShaderTime;
uniform mediump float _Seed;
varying mediump vec2 xlv_TEXCOORD0;
varying mediump vec2 xlv_TEXCOORD1;
varying lowp vec4 xlv_COLOR;
void main ()
{
  lowp vec4 tmpvar_1;
  mediump vec4 col_2;
  mediump float flare_3;
  mediump float flareTex_4;
  highp float tmpvar_5;
  tmpvar_5 = (_ShaderTime + _Seed);
  lowp vec4 tmpvar_6;
  tmpvar_6 = texture2D (_MainTex, xlv_TEXCOORD0);
  mediump float tmpvar_7;
  tmpvar_7 = ((tmpvar_6.x * _Intensity) * 1.2);
  highp vec2 tmpvar_8;
  tmpvar_8.x = ((xlv_TEXCOORD1.x * _UflareScale) + (tmpvar_5 * 0.05));
  tmpvar_8.y = ((tmpvar_7 * _VflareScale) + (tmpvar_5 * _VflareSpeed));
  lowp float tmpvar_9;
  tmpvar_9 = texture2D (_FlareTex, tmpvar_8).x;
  flareTex_4 = tmpvar_9;
  flare_3 = (((
    ((flareTex_4 * xlv_COLOR.x) + tmpvar_7)
   * 2.0) * tmpvar_7) * _FlareIntensity);
  col_2.xyz = (mix (_Color, (_HiColor * flare_3), vec4(flare_3)) * _ColorIntensity).xyz;
  col_2.w = (flare_3 * xlv_COLOR.x);
  tmpvar_1 = (col_2 * _Colorize);
  gl_FragData[0] = tmpvar_1;
}


#endif
"
}
}
Program "fp" {
SubProgram "gles " {
"!!GLES"
}
}
 }
}
Fallback Off
}
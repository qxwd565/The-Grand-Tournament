Shader "Custom/Card/Unlit_Desaturate_2Texture2uv" {
Properties {
 _Color ("Tint Color", Color) = (0.5,0.5,0.5,0.5)
 _MainTex ("Main Texture", 2D) = "white" { }
 _SecondTex ("Second Texture", 2D) = "white" { }
 _SecondTint ("Second Tint Color", Color) = (0.5,0.5,0.5,0.5)
 _BlendIntensity ("Blend Intensity", Float) = 2
 _DarkColor ("Dark Color", Color) = (0.3,0.3,0.3,1)
 _Desaturate ("Desaturate", Float) = 1
 _Contrast ("Contrast", Float) = 1
 _Intensity ("Intensity", Float) = 1
 _AvgLum ("Average Luminosity", Color) = (0.5,0.5,0.5,1)
 _LightingBlend ("Ambient Lighting Blend", Float) = 0
}
SubShader { 
 Tags { "RenderType"="Opaque" "Highlight"="true" }
 Pass {
  Tags { "RenderType"="Opaque" "Highlight"="true" }
  BindChannels {
   Bind "vertex", Vertex
   Bind "color", Color
   Bind "texcoord", TexCoord
  }
  Fog {
   Color (0,0,0,0)
  }
  GpuProgramID 54310
Program "vp" {
SubProgram "gles " {
"!!GLES
#version 100

#ifdef VERTEX
attribute vec4 _glesVertex;
attribute vec4 _glesColor;
attribute vec4 _glesMultiTexCoord0;
attribute vec4 _glesMultiTexCoord1;
uniform highp mat4 glstate_matrix_mvp;
uniform lowp vec4 glstate_lightmodel_ambient;
uniform lowp vec4 _LightColor0;
uniform lowp vec4 _Color;
uniform mediump float _LightingBlend;
uniform highp vec4 _MainTex_ST;
uniform highp vec4 _SecondTex_ST;
varying highp vec2 xlv_TEXCOORD0;
varying highp vec2 xlv_TEXCOORD1;
varying lowp vec4 xlv_COLOR;
void main ()
{
  lowp vec4 tmpvar_1;
  mediump vec4 tmpvar_2;
  lowp vec4 y_3;
  y_3 = ((glstate_lightmodel_ambient * 2.0) + _LightColor0);
  tmpvar_2 = mix (_glesColor, y_3, vec4(_LightingBlend));
  tmpvar_1 = (tmpvar_2 * _Color);
  gl_Position = (glstate_matrix_mvp * _glesVertex);
  xlv_TEXCOORD0 = ((_glesMultiTexCoord0.xy * _MainTex_ST.xy) + _MainTex_ST.zw);
  xlv_TEXCOORD1 = ((_glesMultiTexCoord1.xy * _SecondTex_ST.xy) + _SecondTex_ST.zw);
  xlv_COLOR = tmpvar_1;
}


#endif
#ifdef FRAGMENT
uniform lowp vec4 _Color;
uniform sampler2D _MainTex;
uniform sampler2D _SecondTex;
uniform lowp vec4 _SecondTint;
uniform mediump float _BlendIntensity;
uniform lowp vec4 _DarkColor;
uniform mediump float _Desaturate;
uniform highp float _Contrast;
uniform highp float _Intensity;
uniform lowp vec4 _AvgLum;
varying highp vec2 xlv_TEXCOORD0;
varying highp vec2 xlv_TEXCOORD1;
varying lowp vec4 xlv_COLOR;
void main ()
{
  lowp vec4 tmpvar_1;
  mediump vec4 col_2;
  mediump vec4 main_3;
  lowp vec4 tmpvar_4;
  tmpvar_4 = texture2D (_MainTex, xlv_TEXCOORD0);
  main_3 = tmpvar_4;
  lowp vec4 tmpvar_5;
  tmpvar_5 = texture2D (_SecondTex, xlv_TEXCOORD1);
  mediump vec4 tmpvar_6;
  tmpvar_6 = ((tmpvar_5 * _SecondTint) * _BlendIntensity);
  mediump vec4 tmpvar_7;
  tmpvar_7 = mix (main_3, (main_3 * tmpvar_6), tmpvar_6.wwww);
  mediump vec4 tmpvar_8;
  tmpvar_8 = mix (tmpvar_7, mix (_DarkColor, _Color, vec4(dot (vec3(0.3, 0.59, 0.11), tmpvar_7.xyz))), vec4(_Desaturate));
  highp vec4 tmpvar_9;
  tmpvar_9 = mix (tmpvar_8, _AvgLum, vec4(_Contrast));
  col_2 = tmpvar_9;
  mediump vec4 tmpvar_10;
  tmpvar_10 = min (((col_2 + 0.15) * xlv_COLOR), col_2);
  tmpvar_1 = (tmpvar_10 * _Intensity);
  gl_FragData[0] = tmpvar_1;
}


#endif
"
}
}
Program "fp" {
SubProgram "gles " {
"!!GLES"
}
}
 }
}
Fallback "Diffuse"
}